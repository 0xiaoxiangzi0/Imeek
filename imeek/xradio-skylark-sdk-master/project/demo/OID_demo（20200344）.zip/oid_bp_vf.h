#ifndef _OID_BP_VF_H_
#define _OID_BP_VF_H_

#ifndef _BOOL_
#define _BOOL_
typedef unsigned char MYBOOL;
#endif

#ifndef TRUE
#define TRUE  1
#endif

#ifndef FALSE
#define FALSE 0
#endif


int adc_get(void);

#endif
