#ifndef _RELEASE_TEST_H_
#define _RELEASE_TEST_H_

#ifndef _BOOL_
#define _BOOL_
typedef unsigned char MYBOOL;
#endif

#ifndef TRUE
#define TRUE  1
#endif

#ifndef FALSE
#define FALSE 0
#endif

typedef MYBOOL TestModeFlag;

#endif
